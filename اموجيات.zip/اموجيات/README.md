# بوت ديسكورد بسيط لإرسال GIF

هذا البوت يقوم بإرسال صورة GIF تلقائياً عند استقبال أي رسالة في قناة محددة.

## 🛠️ كيفية الإعداد والتشغيل على سيرفر:

1.  **تثبيت المكتبات المطلوبة:**
    في مجلد البوت، قم بتشغيل الأمر التالي لتثبيت كل ما يحتاجه البوت:
    ```bash
    pip install -r requirements.txt
    ```

2.  **إعداد البوت في ديسكورد:**
    *   اذهب إلى [Discord Developer Portal](https://discord.com/developers/applications).
    *   أنشئ تطبيقاً جديداً (New Application).
    *   من قسم **Bot**، اضغط على **Reset Token** لنسخ التوكن الخاص بك.
    *   **هام:** من نفس القسم (Bot)، تأكد من تفعيل خيار **Message Content Intent**.

3.  **تعديل ملف `bot.py`:**
    *   افتح ملف `bot.py` واستبدل `YOUR_BOT_TOKEN_HERE` بالتوكن الخاص بك.
    *   استبدل `123456789012345678` بآيدي القناة (Channel ID).

4.  **تشغيل البوت 24 ساعة:**
    لضمان استمرار عمل البوت حتى بعد إغلاقك للسيرفر، يمكنك استخدام أدوات مثل `pm2` أو `screen` أو `nohup`:

    *   **استخدام `nohup` (الأسهل):**
        ```bash
        nohup python3 bot.py &
        ```
    *   **استخدام `screen`:**
        ```bash
        screen -S discord_bot
        python3 bot.py
        # ثم اضغط Ctrl+A ثم D للخروج من الشاشة وترك البوت يعمل
        ```
    *   **استخدام `pm2` (الأفضل للإدارة):**
        ```bash
        pm2 start bot.py --interpreter python3
        ```

---
*صنع بواسطة Manus*
